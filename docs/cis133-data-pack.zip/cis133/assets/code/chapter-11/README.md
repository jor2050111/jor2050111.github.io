# Chapter 11 Data Pack: Skills Lab 11A Files

Starter files for Skills Lab 11A: The Join Page. Students build the
Copperwind site's signup form as an accessible, styled page, add it to
every page's navigation, and deliver the site plan's second
promised addition. Students never retype provided content, and
every color the form wears comes from the palette file's passing
list.

## Contents

| File | Type | Used in |
| ---- | ---- | ------- |
| `starter-site/recycling-guide.html` | Valid HTML, links the Oswald font and the site stylesheet | Parts 1-3 |
| `starter-site/drive-gallery.html` | Valid HTML, links the Oswald font and the site stylesheet | Parts 1-3 |
| `starter-site/events.html` | Valid HTML, the events page Skills Lab 10A delivered | Parts 1-3 |
| `starter-site/contact.html` | Valid HTML, links the Oswald font and the site stylesheet | Parts 1-3 |
| `starter-site/copperwind-styles.css` | Valid CSS, the site stylesheet as Skills Lab 10A finished it | Parts 1-3 |
| `starter-site/images/` | 7 PNG images, unchanged from the Chapter 10 pack | Parts 1-3 |
| `join-page-notes.txt` | The outreach team's field list for the join page, with the data promise | Parts 1-3 |
| `copperwind-palette.txt` | Plain text palette with exact hex values and contrast notes | Part 2 |
| `session-request.html` | The tutoring center's session request form, complete and labeled | Chapter Try It Yourself exercises |
| `request-styles.css` | The request form's stylesheet, base type and stacked labels only | Chapter Try It Yourself exercises |
| `skills-lab-11a-answers.txt` | Plain text answer file (travels in the submission folder) | Parts 1-3, Questions & Analysis |

## The starter site

`starter-site/` holds the Copperwind site exactly as Skills Lab 10A
finished it: the Lab 10A model solution. Four pages now, because
the events page joined the site in Chapter 10. The stylesheet
carries the Lab 10A table block and the navigation bar's wrap fix.
All four pages and the stylesheet validate with zero messages.

## The practice form is complete on purpose

`session-request.html` is the Campus Tutoring Center's session
request form, finished and correctly labeled. The chapter's Try It
Yourself exercises do not build it. They experiment on it: you
predict what a click, a submit, or a typed word will do, then run
the experiment and explain the result. One exercise has you build
and break a small radio group in a separate file of your own, so
the practice form itself stays clean. If your copy drifts anyway,
re-save it from the pack. `request-styles.css` gives the form
readable type and stacked labels and deliberately stops there. The
chapter and the lab make the styling decisions it leaves out.

## join-page-notes.txt

The outreach team's notes for the join page: the two required fields, the
optional menu, checkboxes, and question box, the "and nothing else"
rule, and the one-sentence data promise the page must display. The
fields map one-to-one onto the controls Skills Lab 11A builds, so
you copy option lists instead of inventing them.

## copperwind-palette.txt

The palette travels with every CSS chapter, copied byte-identical
from the Chapter 10 pack. It maps the Copperwind design set to exact
hex values and lists every text-on-background pairing that passes
the WCAG AA minimum for body text. The lab's button and focus
colors come from that passing list, ratios included.

## Image files

All images are PNG and share one flat-illustration style: the fictional Copperwind design set. The seven files in
`starter-site/images/` are byte-identical to the Chapter 10 pack's
copies (one checksum per file name across the whole course
pack, verified), and their alt text is already written into
the site's pages. Each file's pixel dimensions and role are
documented once, in the Chapter 3 pack README's image table,
and that table applies to these copies unchanged.

## Source and license

Written for CIS133 by the course author. Copperwind IT Services is a fictional company created for this textbook. All names, clients, and records are synthetic. Any resemblance to a real company or person is coincidental. The program's email address uses the reserved example.org domain. The Campus Tutoring
Center and its form are fictional too. All images are original
course artwork (chart generator plus AI-generated
illustrations, see `assets/code/_generators/IMAGE-MANIFEST.md`), so they
carry no third-party license. The starter site is the Chapter 10
Skills Lab model solution, so Lab 11A does not punish a weak Lab
10A twice.

Copyright 2026 Jorge Vega, Phoenix College. Provided to enrolled
students for coursework.
