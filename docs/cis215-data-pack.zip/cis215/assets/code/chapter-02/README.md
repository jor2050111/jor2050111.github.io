# Chapter 2 Data

## cafe_sales.csv

Five years of monthly financials for a campus cafe (2021-2025). Used
in Skills Lab 2A. 60 rows, 5 columns.

| Column | Type | Description |
|--------|------|-------------|
| year | integer | Calendar year (2021-2025) |
| month | text | Month name (January-December) |
| revenue | integer | Monthly revenue in US dollars |
| expenses | integer | Monthly expenses in US dollars |
| customers_served | integer | Customer transactions that month |

Revenue always exceeds expenses, revenue trends upward year over
year, and summer months dip because the campus empties out.

**Load from the data pack root:**

```python
df_cafe_sales = pd.read_csv('assets/code/chapter-02/cafe_sales.csv')
```

**Source:** Synthetic, generated with a fixed seed by
`_generators/generate_synthetic_datasets.py`.

## copperwind_tickets_january.csv

The same January ticket file introduced in Chapter 1, shipped here so
this chapter stands alone. Used in Try It Yourself 2.5 to practice
documenting an analysis with Markdown cells. 60 rows, 6 columns.

| Column | Type | Description |
|--------|------|-------------|
| ticket_id | text | Ticket identifier (T-2601 to T-2660) |
| opened_date | date | Date opened, January 2026 |
| category | text | Hardware, Software, Network, Security, or Accounts |
| priority | text | Low, Medium, High, or Critical |
| resolution_hours | float | Hours from open to close |
| satisfaction | integer | Client survey score, 1-5 |

**Load from the data pack root:**

```python
df_tickets = pd.read_csv(
    'assets/code/chapter-02/copperwind_tickets_january.csv'
)
```

**Source:** Seeded synthetic data from
`_generators/generate_copperwind_data.py` (base seed 215,
byte-identical on rerun). Copperwind IT Services is a fictional
company created for this textbook. All names, clients, and
records are synthetic. Any resemblance to a real company or
person is coincidental.
