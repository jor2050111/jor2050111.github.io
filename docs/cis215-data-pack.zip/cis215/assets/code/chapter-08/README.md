# Chapter 8 Data

## regional_sales.csv

Wide-format quarterly revenue for 15 products across 4 regions, used
in Skills Lab 8A. The wide layout is intentional: melting Q1-Q4 into
long format is one of the lab's core tasks. 60 rows, 7 columns.

| Column | Type | Description |
|--------|------|-------------|
| product | text | Product name (15 products) |
| category | text | Product category (6 categories) |
| region | text | East, West, South, or North |
| Q1_revenue | integer | Quarter 1 revenue, US dollars |
| Q2_revenue | integer | Quarter 2 revenue, US dollars |
| Q3_revenue | integer | Quarter 3 revenue, US dollars |
| Q4_revenue | integer | Quarter 4 revenue, US dollars |

Computer products spike in Q4 (holiday season) and the West region
runs strongest, so the pivot tables show real seasonal and regional
patterns.

## customer_reviews.csv

Individual product reviews that students aggregate to product level
before merging with the sales data. 90 rows, 5 columns.

| Column | Type | Description |
|--------|------|-------------|
| review_id | integer | Unique review ID |
| product | text | Product name (matches regional_sales.csv) |
| rating | integer | Star rating, 1-5 |
| verified_purchase | boolean | Whether the purchase was verified |
| review_date | date | Review date (2026) |

Average ratings vary by product; some clear 4.0 and some do not, so
the satisfaction filters in Part 3 split the catalog.

**Load from the data pack root:**

```python
df_sales_regional = pd.read_csv(
    'assets/code/chapter-08/regional_sales.csv'
)
df_reviews = pd.read_csv('assets/code/chapter-08/customer_reviews.csv')
```

**Source:** Synthetic, generated with a fixed seed by
`_generators/generate_synthetic_datasets.py`.

## copperwind_tickets.csv

The six-month Copperwind ticket file (also used in Chapters 4 and 5),
shipped here so this chapter stands alone. Used in Try It Yourself
8.5 for pivot tables and merging. Every team and priority
combination is populated by design, so the pivot has no empty cells.
200 rows, 7 columns.

| Column | Type | Description |
|--------|------|-------------|
| ticket_id | text | Ticket identifier (T-1001 to T-1200) |
| opened_date | date | Date opened, January-June 2026 |
| category | text | Hardware, Software, Network, Security, or Accounts |
| priority | text | Low, Medium, High, or Critical |
| technician | text | Assigned technician |
| team | text | Deskside or Network Ops |
| resolution_hours | float | Hours from open to close, right-skewed |

## copperwind_technicians.csv

Copperwind's technician roster, used as the merge partner in Try It
Yourself 8.5. 8 rows, 5 columns.

| Column | Type | Description |
|--------|------|-------------|
| technician | text | Technician full name |
| team | text | Deskside or Network Ops |
| hire_year | integer | Year hired |
| certification | text | Primary certification |
| weekly_capacity | integer | Scheduled hours per week |

**Load from the data pack root:**

```python
df_tickets = pd.read_csv('assets/code/chapter-08/copperwind_tickets.csv')
df_techs = pd.read_csv(
    'assets/code/chapter-08/copperwind_technicians.csv'
)
```

**Source:** Seeded synthetic data from
`_generators/generate_copperwind_data.py` (base seed 215,
byte-identical on rerun). Copperwind IT Services is a fictional
company created for this textbook. All names, clients, and
records are synthetic. Any resemblance to a real company or
person is coincidental.
