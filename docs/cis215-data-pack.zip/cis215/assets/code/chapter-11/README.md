# Chapter 11 Data

Five linked files for the multi-source integration Skills Lab 11A.
The CSV, JSON, and Excel files share keys so merges produce clean
matches, and the SQLite database mirrors the same records as tables.

## retail_sales.csv

Sales transactions. 300 rows, 5 columns.

| Column | Type | Description |
|--------|------|-------------|
| sale_id | integer | Unique sale ID |
| date | date | Sale date (2026) |
| product_id | integer | Joins to products.json (1-50) |
| quantity | integer | Units sold |
| price | float | Unit price at sale time, US dollars |

## products.json

Product catalog as a JSON array of records. 50 records, 5 fields:
`product_id`, `name`, `category`, `unit_price`, `supplier`.

## customers.xlsx

Customer roster on sheet `Customers`. 60 rows, 5 columns:
`customer_id`, `name`, `city`, `state`, `signup_date`. Names are
fictional.

## store.db

SQLite database for the hands-on SQL work in Section 11.4. Three
tables mirror the other sources so query results reconcile with the
files: `products` (50 rows, same fields as products.json), `sales`
(300 rows, same fields as retail_sales.csv), and `customers`
(60 rows, same fields as customers.xlsx). Connect with the standard
library:

```python
import sqlite3

conn = sqlite3.connect('assets/code/chapter-11/store.db')
```

## states_table.html

Offline fallback for the lab's `pd.read_html()` task: a simplified
copy of the Wikipedia table "List of U.S. states and territories by
population" (State, Population_2025_Est, Population_2020_Census,
House_Seats). Use it if the live page changes or internet is
unavailable:

```python
df_states = pd.read_html(
    'assets/code/chapter-11/states_table.html'
)[0]
```

**Load the other files from the data pack root:**

```python
df_retail = pd.read_csv('assets/code/chapter-11/retail_sales.csv')
df_products = pd.read_json('assets/code/chapter-11/products.json')
df_customers = pd.read_excel(
    'assets/code/chapter-11/customers.xlsx'
)
```

**Source:** Sales, catalog, and customers are synthetic, generated
with a fixed seed by `_generators/generate_synthetic_datasets.py`.
The states table is real Wikipedia/US Census data captured by
`_generators/prepare_real_datasets.py`.

## copperwind_clients.json

Copperwind's 40 client companies as nested JSON records, used in Try
It Yourself 11.6. Each record nests a contract object (tier and
renewal_year), so a plain read_json leaves dictionary-valued columns
and json_normalize is the right tool. 40 records.

| Field | Type | Description |
|--------|------|-------------|
| client_id | text | Client identifier (C-001 to C-040) |
| name | text | Fictional Valley business name |
| industry | text | One of 8 industries |
| city | text | Phoenix-area city |
| seats | integer | Supported seats at the client |
| contract.tier | text | Basic, Standard, or Premium (nested) |
| contract.renewal_year | integer | Contract renewal year (nested) |

## copperwind_tickets_q1.csv

Copperwind's first-quarter 2026 tickets with client identifiers, the
merge partner for the client list in Try It Yourself 11.6. Every
client_id resolves against copperwind_clients.json. 90 rows,
6 columns.

| Column | Type | Description |
|--------|------|-------------|
| ticket_id | text | Ticket identifier (T-5001 to T-5090) |
| opened_date | date | Date opened, January-March 2026 |
| category | text | Hardware, Software, Network, Security, or Accounts |
| priority | text | Low, Medium, High, or Critical |
| client_id | text | Joins to copperwind_clients.json |
| resolution_hours | float | Hours from open to close |

**Load from the data pack root:**

```python
import json

with open('assets/code/chapter-11/copperwind_clients.json') as fh:
    client_records = json.load(fh)
df_clients = pd.json_normalize(client_records)
df_q1 = pd.read_csv('assets/code/chapter-11/copperwind_tickets_q1.csv')
```

**Source:** Seeded synthetic data from
`_generators/generate_copperwind_data.py` (base seed 215,
byte-identical on rerun). Copperwind IT Services is a fictional
company created for this textbook. All names, clients, and
records are synthetic. Any resemblance to a real company or
person is coincidental.
