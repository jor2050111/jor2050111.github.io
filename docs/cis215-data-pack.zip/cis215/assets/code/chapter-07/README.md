# Chapter 7 Data

## city_temperatures.csv

Monthly climate normals for five US cities in long format, used in
the visualization Skills Lab 7A. 60 rows (5 cities x 12 months),
6 columns.

| Column | Type | Description |
|--------|------|-------------|
| City | text | Phoenix, New York, Chicago, Los Angeles, or Miami |
| Month_Num | integer | Month number (1-12) |
| Month_Name | text | Month name |
| Avg_High_F | float | Average daily high, degrees Fahrenheit |
| Avg_Low_F | float | Average daily low, degrees Fahrenheit |
| Precip_In | float | Average precipitation, inches |

The five cities contrast desert (Phoenix), coastal (Los Angeles),
continental (Chicago, New York), and tropical (Miami) climates, so
questions about stability and variation have clear answers.

**Load from the data pack root:**

```python
df_temps = pd.read_csv('assets/code/chapter-07/city_temperatures.csv')
```

**Source:** Transcribed and rounded from the NOAA 1991-2020 US
Climate Normals (public domain). Values live in
`_generators/prepare_real_datasets.py`.

## copperwind_monthly_volume.csv

Thirty months of Copperwind ticket volume, used in Try It Yourself
7.5. Summer months (June-August) run at least 25 percent above the
rest by design: desert heat and monsoon storms are hard on hardware.
The spike is obvious in a line plot, which is the point. 30 rows,
5 columns.

| Column | Type | Description |
|--------|------|-------------|
| month | text | Year-month, 2024-01 through 2026-06 |
| tickets_opened | integer | Tickets opened that month |
| tickets_closed | integer | Tickets closed that month |
| avg_resolution_hours | float | Average hours to resolve |
| critical_count | integer | Critical-priority tickets that month |

**Load from the data pack root:**

```python
df_volume = pd.read_csv(
    'assets/code/chapter-07/copperwind_monthly_volume.csv'
)
```

**Source:** Seeded synthetic data from
`_generators/generate_copperwind_data.py` (base seed 215,
byte-identical on rerun). Copperwind IT Services is a fictional
company created for this textbook. All names, clients, and
records are synthetic. Any resemblance to a real company or
person is coincidental.
