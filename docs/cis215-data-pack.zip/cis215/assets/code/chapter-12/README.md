# Chapter 12 Data

## penguins.csv

The Palmer Penguins dataset: body measurements for 344 penguins of
three species recorded near Palmer Station, Antarctica. Provided as
the ready-to-use fallback for the portfolio Skills Lab 12A; choosing
your own public dataset is still encouraged. 344 rows, 7 columns.

| Column | Type | Description |
|--------|------|-------------|
| species | text | Adelie, Chinstrap, or Gentoo |
| island | text | Island where observed |
| bill_length_mm | float | Bill length, millimeters |
| bill_depth_mm | float | Bill depth, millimeters |
| flipper_length_mm | float | Flipper length, millimeters |
| body_mass_g | float | Body mass, grams |
| sex | text | MALE or FEMALE |

The file includes a small number of genuinely missing values, which
gives the cleaning and bias-assessment tasks authentic material.

**Load from the data pack root:**

```python
df_penguins = pd.read_csv('assets/code/chapter-12/penguins.csv')
```

**Source:** Horst AM, Hill AP, Gorman KB (2020), palmerpenguins
dataset, CC0 public domain; copied from the seaborn-data repository.
See `_generators/prepare_real_datasets.py`.

## copperwind_tickets_full.csv

Copperwind's complete ticket history, the dataset behind Try It
Yourself 12.5 and the Copperwind option in Skills Lab 12A. Engineered
and verified by the generator: satisfaction is missing on roughly 35
percent of after-hours tickets but only about 8 percent of
business-hours tickets. The survey silence is not random, which is
the bias lesson in Section 12.1. 900 rows, 11 columns.

| Column | Type | Description |
|--------|------|-------------|
| ticket_id | text | Ticket identifier (T-10001 to T-10900) |
| opened_date | date | Date opened, 2024-01 through 2026-06 |
| closed_date | date | Date closed |
| category | text | Hardware, Software, Network, Security, or Accounts |
| priority | text | Low, Medium, High, or Critical |
| team | text | Deskside or Network Ops |
| technician | text | Assigned technician |
| client_id | text | Joins to copperwind_clients.json |
| resolution_hours | float | Hours from open to close |
| satisfaction | float | Survey score 1-5, missing by a biased pattern |
| after_hours | boolean | Opened outside business hours |

## copperwind_clients.json

The 40 Copperwind client records (same file as Chapter 11), shipped
here so the capstone option stands alone. See the Chapter 11 README
for the field dictionary.

## copperwind_technicians.csv

The 8-row technician roster (same file as Chapter 8), shipped here
for the capstone option. See the Chapter 8 README for the column
dictionary.

**Load from the data pack root:**

```python
df_tickets = pd.read_csv(
    'assets/code/chapter-12/copperwind_tickets_full.csv'
)
```

**Source:** Seeded synthetic data from
`_generators/generate_copperwind_data.py` (base seed 215,
byte-identical on rerun). Copperwind IT Services is a fictional
company created for this textbook. All names, clients, and
records are synthetic. Any resemblance to a real company or
person is coincidental.
