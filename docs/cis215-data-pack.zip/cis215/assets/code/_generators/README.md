# Dataset Generators

Author-facing scripts that build every data file in the course data
pack. Students never need to run these; they document where each file
came from and make every dataset reproducible.

## Scripts

* `prepare_real_datasets.py` -- downloads and prepares the real public
  datasets (Gapminder, US cities, Palmer Penguins, the offline states
  table) and writes the transcribed NOAA climate normals.
* `generate_synthetic_datasets.py` -- builds every synthetic dataset
  with seeded random generation (base seed 215). Each build function
  documents and asserts the pedagogical properties the matching
  Skills Lab depends on, such as guaranteed missing values in the
  Chapter 6 survey and the significant teaching-method t-test in the
  Chapter 9 data.

## Regenerating the data pack

```bash
python prepare_real_datasets.py
python generate_synthetic_datasets.py
```

Both scripts write into the `assets/code/chapter-NN/` folders relative
to this directory. The synthetic script produces byte-identical files
on every run; the real-data script depends on the upstream sources, so
avoid rerunning it mid-semester unless a source file is lost.
