"""Generate the Copperwind IT Services spine datasets.

Copperwind IT Services is the fictional Phoenix managed-services
company that threads all twelve chapters (the resumable spine from
docs/pedagogy-upgrade-plan-2026-07-28.md). Every file is seeded so
regeneration produces byte-identical output, and every engineered
property a chapter depends on is asserted here:

* chapter-04/05/08 tickets: exact filter counts for Try It Yourself
  4.5, right-skewed resolution hours (mean-median gap) for 5.5, and
  a fully populated team x priority grid for the 8.5 pivot.
* chapter-06 export: exact duplicate rows, category spelling chaos,
  missing satisfaction, and 'pending' strings that force an object
  dtype ('N/A' would vanish into the pandas default NA list).
* chapter-07 monthly volume: a June-August spike (desert summers are
  hard on hardware) that the line plot must show.
* chapter-09 SLA study: a significant Old-vs-New triage t-test, an
  honest null on satisfaction, and six missing satisfaction values
  that feed the silent-nan Fix It.
* chapter-10 weekly metrics: exact missing-value counts so cleaning
  functions have real work.
* chapter-11 clients: nested contract records that require
  json_normalize, and Q1 tickets whose client_ids all resolve.
* chapter-12 full history: satisfaction goes missing far more often
  on after-hours tickets (the bias lesson in 12.1).

Run from anywhere; paths resolve relative to this file:

    python generate_copperwind_data.py
"""

import json
from datetime import date, timedelta
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats

ASSETS = Path(__file__).resolve().parents[1]
SEED = 215  # course number, used as the base seed everywhere

CATEGORIES = ["Hardware", "Software", "Network", "Security", "Accounts"]
PRIORITIES = ["Low", "Medium", "High", "Critical"]

TECHNICIANS = [
    ("Priya Sharma", "Deskside", 2019, "CompTIA A+", 40),
    ("Malik Johnson", "Deskside", 2021, "CompTIA A+", 40),
    ("Mei Lin", "Network Ops", 2018, "CCNA", 40),
    ("Diego Ramos", "Deskside", 2022, "CompTIA A+", 32),
    ("Amara Okafor", "Network Ops", 2020, "CCNA", 40),
    ("Sofia Reyes", "Deskside", 2023, "CompTIA A+", 24),
    ("Ethan Cole", "Deskside", 2024, "CompTIA A+", 40),
    ("Naomi Redhouse", "Network Ops", 2021, "Network+", 40),
]
TECH_NAMES = [t[0] for t in TECHNICIANS]
TECH_TEAM = {t[0]: t[1] for t in TECHNICIANS}

VALLEY_CITIES = ["Phoenix", "Mesa", "Tempe", "Chandler", "Glendale",
                 "Scottsdale", "Gilbert", "Peoria", "Surprise",
                 "Avondale"]

# 40 fictional Valley client businesses. Names are invented for the
# textbook; the folder READMEs carry the fictional disclaimer.
CLIENTS = [
    ("Agave Family Dental", "Healthcare"),
    ("Camelback Kids Clinic", "Healthcare"),
    ("Verde River Physical Therapy", "Healthcare"),
    ("Sunrise Ridge Counseling", "Healthcare"),
    ("Desert Bloom Optometry", "Healthcare"),
    ("Mesquite Legal Group", "Legal"),
    ("Fourth Avenue Law", "Legal"),
    ("Salt River Title", "Legal"),
    ("Estrella Mediation Partners", "Legal"),
    ("Roadrunner Charter Academy", "Education"),
    ("Cholla Prep", "Education"),
    ("Little Sprouts Preschool", "Education"),
    ("Palo Brea Tutoring", "Education"),
    ("Cactus Flats Trading Post", "Retail"),
    ("Adobe Home Goods", "Retail"),
    ("Sonoran Cycle Works", "Retail"),
    ("Thunderhead Outfitters", "Retail"),
    ("Marigold Market", "Retail"),
    ("Copper Kettle Coffee", "Retail"),
    ("Second Street Books", "Retail"),
    ("Valley Hearts Food Bank", "Nonprofit"),
    ("Desert Paws Rescue", "Nonprofit"),
    ("New Roots Refugee Services", "Nonprofit"),
    ("Bright Futures Mentoring", "Nonprofit"),
    ("Gila Bend Fabrication", "Manufacturing"),
    ("Redtail Precision Machining", "Manufacturing"),
    ("Cactus Wren Signworks", "Manufacturing"),
    ("Ironwood Cabinet Co", "Manufacturing"),
    ("Pinnacle West Accounting", "Finance"),
    ("Ocotillo Tax Partners", "Finance"),
    ("Mesa Verde Credit Advisors", "Finance"),
    ("Quartz Rock Insurance", "Finance"),
    ("Dry Heat Brewing", "Hospitality"),
    ("Luna Azul Cantina", "Hospitality"),
    ("Tumbleweed Event Hall", "Hospitality"),
    ("Vista del Sol Suites", "Hospitality"),
    ("Javelina Junction BBQ", "Hospitality"),
    ("Superstition Trail Tours", "Hospitality"),
    ("Goldfield Property Group", "Finance"),
    ("Papago Park Pediatrics", "Healthcare"),
]


def date_strings(rng, start, end, n, sort=True):
    """Draw n dates in [start, end] and return ISO strings."""
    span = (end - start).days
    offsets = rng.integers(0, span + 1, n)
    if sort:
        offsets = np.sort(offsets)
    return [(start + timedelta(days=int(o))).isoformat()
            for o in offsets]


def build_tickets_january():
    """chapter-01 and chapter-02: the first-look file, 60 x 6."""
    rng = np.random.default_rng(SEED + 1)
    n = 60
    # Guarantee every category appears, then fill the rest randomly.
    category = CATEGORIES * 3 + list(
        rng.choice(CATEGORIES, n - 15,
                   p=[0.30, 0.28, 0.18, 0.10, 0.14])
    )
    category = list(np.array(category)[rng.permutation(n)])
    priority = list(rng.choice(PRIORITIES, n, p=[0.25, 0.40, 0.25, 0.10]))
    hours = np.round(np.clip(rng.lognormal(1.1, 0.8, n), 0.3, 24.0), 1)
    df = pd.DataFrame({
        "ticket_id": [f"T-{2600 + i}" for i in range(1, n + 1)],
        "opened_date": date_strings(rng, date(2026, 1, 2),
                                    date(2026, 1, 30), n),
        "category": category,
        "priority": priority,
        "resolution_hours": hours,
        "satisfaction": rng.choice([1, 2, 3, 4, 5], n,
                                   p=[0.04, 0.08, 0.16, 0.38, 0.34]),
    })
    assert df.shape == (60, 6)
    assert set(df["category"]) == set(CATEGORIES)
    assert df["resolution_hours"].isna().sum() == 0
    for folder in ("chapter-01", "chapter-02"):
        df.to_csv(ASSETS / folder / "copperwind_tickets_january.csv",
                  index=False)
    return df


def build_tickets_main():
    """chapter-04/05/08: the 200 x 7 workhorse ticket file.

    Engineered exactly: 12 Critical, 38 Network, 4 Critical Network,
    11 Network tickets over 8 hours. Right-skewed hours overall, and
    every team x priority cell populated for the chapter 8 pivot.
    """
    rng = np.random.default_rng(SEED + 4)
    n = 200

    # Constructive assembly so the counts are exact, then one shared
    # permutation so the file reads as an ordinary export.
    category = (["Network"] * 38 + ["Hardware"] * 52 + ["Software"] * 46
                + ["Security"] * 30 + ["Accounts"] * 34)
    priority = (
        ["Critical"] * 4 + ["High"] * 9 + ["Medium"] * 15 + ["Low"] * 10
        + ["Critical"] * 8 + ["High"] * 38 + ["Medium"] * 70 + ["Low"] * 46
    )
    # Network rows: exactly 11 over 8 hours.
    net_hours = np.concatenate([
        np.round(rng.uniform(8.5, 24.0, 11), 1),
        np.round(rng.uniform(0.5, 7.9, 27), 1),
    ])
    other_hours = np.round(
        np.clip(rng.lognormal(1.05, 0.85, n - 38), 0.3, 40.0), 1
    )
    # Keep the non-Network side honest: nothing at or above the
    # 8-hour line sneaks into Network-only counting (the TIY filters
    # on category AND hours, so this is belt and suspenders only).
    hours = np.concatenate([net_hours, other_hours])

    technician = rng.choice(TECH_NAMES, n)
    # The pivot lesson needs every team x priority cell nonzero. Pin
    # two Critical rows to opposite teams so no seed can empty a cell.
    technician[0] = "Mei Lin"        # Critical + Network Ops
    technician[42] = "Priya Sharma"  # Critical + Deskside

    perm = rng.permutation(n)
    category = list(np.array(category)[perm])
    priority = list(np.array(priority)[perm])
    hours = hours[perm]
    technician = list(np.array(technician)[perm])
    team = [TECH_TEAM[t] for t in technician]

    df = pd.DataFrame({
        "ticket_id": [f"T-{1000 + i}" for i in range(1, n + 1)],
        "opened_date": date_strings(rng, date(2026, 1, 2),
                                    date(2026, 6, 30), n),
        "category": category,
        "priority": priority,
        "technician": technician,
        "team": team,
        "resolution_hours": hours,
    })

    assert df.shape == (200, 7)
    assert (df["priority"] == "Critical").sum() == 12
    assert (df["category"] == "Network").sum() == 38
    assert ((df["category"] == "Network")
            & (df["priority"] == "Critical")).sum() == 4
    assert ((df["category"] == "Network")
            & (df["resolution_hours"] > 8)).sum() == 11
    skew_gap = df["resolution_hours"].mean() - df["resolution_hours"].median()
    assert skew_gap >= 1.5, f"skew gap {skew_gap:.2f} under 1.5"
    grid = df.pivot_table(index="team", columns="priority",
                          values="ticket_id", aggfunc="count")
    assert grid.notna().all().all(), "empty team x priority cell"

    for folder in ("chapter-04", "chapter-05", "chapter-08"):
        df.to_csv(ASSETS / folder / "copperwind_tickets.csv", index=False)
    return df


def build_tickets_export():
    """chapter-06: the messy 110 x 6 export students clean."""
    rng = np.random.default_rng(SEED + 6)
    n_base = 104
    category_clean = list(
        rng.choice(CATEGORIES, n_base, p=[0.30, 0.26, 0.18, 0.12, 0.14])
    )
    # At least 8 distinct raw spellings across the five categories.
    # Stamped onto fixed rows so the chaos survives any seed change.
    chaos_stamps = {
        3: "hardware", 11: "HARDWARE", 19: " Hardware",
        27: "software", 35: "Software ", 43: " network",
        51: "NETWORK", 59: "security ", 67: "accounts",
        75: "hardware", 83: " network", 91: "Software ",
    }
    category = list(category_clean)
    for idx, raw in chaos_stamps.items():
        category[idx] = raw

    hours = np.round(np.clip(rng.lognormal(1.1, 0.8, n_base), 0.3, 30.0), 1)
    hours = hours.astype(object)
    for idx in (7, 26, 44, 63, 88):  # unresolved tickets in the export
        hours[idx] = "pending"

    satisfaction = rng.choice([1.0, 2.0, 3.0, 4.0, 5.0], n_base,
                              p=[0.05, 0.09, 0.18, 0.36, 0.32])
    satisfaction = satisfaction.astype(object)
    # Keep the duplicated source rows complete so the file holds
    # exactly 12 empties after the six copies are appended.
    dupe_sources = {9, 27, 41, 58, 73, 90}
    candidates = np.array(
        [i for i in range(n_base) if i not in dupe_sources]
    )
    missing_idx = rng.choice(candidates, 12, replace=False)
    for idx in missing_idx:
        satisfaction[idx] = ""

    df = pd.DataFrame({
        "ticket_id": [f"T-{3000 + i}" for i in range(1, n_base + 1)],
        "opened_date": date_strings(rng, date(2026, 1, 5),
                                    date(2026, 2, 27), n_base),
        "category": category,
        "priority": rng.choice(PRIORITIES, n_base,
                               p=[0.25, 0.40, 0.25, 0.10]),
        "resolution_hours": hours,
        "satisfaction": satisfaction,
    })
    # Exactly six fully duplicated rows, as double-entered tickets.
    dupes = df.iloc[[9, 27, 41, 58, 73, 90]]
    df = pd.concat([df, dupes], ignore_index=True)

    assert df.shape == (110, 6)
    assert df.duplicated().sum() == 6
    raw_spellings = set(df["category"])
    assert len(raw_spellings - set(CATEGORIES)) >= 8
    assert (df["satisfaction"] == "").sum() == 12
    assert (df["resolution_hours"] == "pending").sum() >= 5

    df.to_csv(ASSETS / "chapter-06" / "copperwind_tickets_export.csv",
              index=False)
    # Read-back contract: 'pending' survives as a string, so the
    # column arrives non-numeric (pandas 3.0 shows dtype `str`) and
    # the missing satisfactions arrive as NaN. That is the chapter 6
    # lesson.
    check = pd.read_csv(
        ASSETS / "chapter-06" / "copperwind_tickets_export.csv"
    )
    assert not pd.api.types.is_numeric_dtype(check["resolution_hours"])
    assert (check["resolution_hours"] == "pending").sum() >= 5
    assert check["satisfaction"].isna().sum() == 12
    return df


def build_monthly_volume():
    """chapter-07: 30 months of volume with a summer spike."""
    rng = np.random.default_rng(SEED + 7)
    months = pd.period_range("2024-01", "2026-06", freq="M")
    rows = []
    for m in months:
        base = 235 + int(rng.integers(-25, 26))
        opened = int(base * 1.38) if m.month in (6, 7, 8) else base
        closed = opened - int(rng.integers(0, 18))
        rows.append({
            "month": str(m),
            "tickets_opened": opened,
            "tickets_closed": closed,
            "avg_resolution_hours": round(float(rng.uniform(4.0, 8.2)), 1),
            "critical_count": int(rng.integers(8, 21)),
        })
    df = pd.DataFrame(rows)
    assert df.shape == (30, 5)
    summer = df["month"].str[5:].isin(["06", "07", "08"])
    ratio = (df.loc[summer, "tickets_opened"].mean()
             / df.loc[~summer, "tickets_opened"].mean())
    assert ratio >= 1.25, f"summer ratio {ratio:.2f} under 1.25"
    df.to_csv(ASSETS / "chapter-07" / "copperwind_monthly_volume.csv",
              index=False)
    return df


def build_technicians():
    """chapter-08 and chapter-12: the 8 x 5 technician roster."""
    df = pd.DataFrame(TECHNICIANS, columns=[
        "technician", "team", "hire_year", "certification",
        "weekly_capacity",
    ])
    assert df.shape == (8, 5)
    assert list(df["technician"]) == TECH_NAMES
    for folder in ("chapter-08", "chapter-12"):
        df.to_csv(ASSETS / folder / "copperwind_technicians.csv",
                  index=False)
    return df


def build_sla_study():
    """chapter-09: Old vs New triage study, 160 x 6.

    Engineered: the resolution-hours t-test is significant (New is
    faster), the satisfaction t-test is an honest null, and exactly
    six satisfaction values are missing so a careless t-test returns
    nan (the chapter 9 Fix It).
    """
    rng = np.random.default_rng(SEED + 9)
    n_group = 80
    old_hours = np.round(
        np.clip(rng.normal(9.5, 3.2, n_group), 0.5, 25.0), 1
    )
    new_hours = np.round(
        np.clip(rng.normal(7.2, 3.0, n_group), 0.5, 25.0), 1
    )

    # Identical value counts in both groups make the satisfaction
    # comparison a designed null, not a lucky draw.
    sat_multiset = ([5] * 26 + [4] * 30 + [3] * 14 + [2] * 6 + [1] * 4)
    old_sat = np.array(sat_multiset, dtype=object)
    new_sat = np.array(sat_multiset, dtype=object)
    rng.shuffle(old_sat)
    rng.shuffle(new_sat)
    for idx in (11, 37, 62):
        old_sat[idx] = ""
    for idx in (5, 48, 71):
        new_sat[idx] = ""

    df = pd.DataFrame({
        "ticket_id": [f"S-{100 + i}" for i in range(1, 2 * n_group + 1)],
        "process": ["Old"] * n_group + ["New"] * n_group,
        "resolution_hours": np.concatenate([old_hours, new_hours]),
        "category": rng.choice(CATEGORIES, 2 * n_group),
        "first_response_minutes": np.round(
            np.clip(rng.normal(24, 9, 2 * n_group), 3, 70), 0
        ).astype(int),
        "satisfaction": np.concatenate([old_sat, new_sat]),
    })

    assert df.shape == (160, 6)
    t_res = stats.ttest_ind(old_hours, new_hours, equal_var=False)
    assert t_res.pvalue < 0.01, f"hours p={t_res.pvalue:.4f}"
    assert new_hours.mean() < old_hours.mean()
    clean_old = np.array([v for v in old_sat if v != ""], dtype=float)
    clean_new = np.array([v for v in new_sat if v != ""], dtype=float)
    t_sat = stats.ttest_ind(clean_old, clean_new, equal_var=False)
    assert t_sat.pvalue > 0.30, f"satisfaction p={t_sat.pvalue:.4f}"
    assert (df["satisfaction"] == "").sum() == 6

    df.to_csv(ASSETS / "chapter-09" / "copperwind_sla_study.csv",
              index=False)
    # Read-back contract for the Fix It: nan result, no exception.
    check = pd.read_csv(ASSETS / "chapter-09" / "copperwind_sla_study.csv")
    naive = stats.ttest_ind(
        check.loc[check["process"] == "Old", "satisfaction"],
        check.loc[check["process"] == "New", "satisfaction"],
    )
    assert np.isnan(naive.pvalue)
    return df


def build_weekly_metrics():
    """chapter-10: 60 weeks of metrics with exact missing counts."""
    rng = np.random.default_rng(SEED + 10)
    start = date(2025, 1, 6)  # a Monday
    weeks = [start + timedelta(weeks=i) for i in range(60)]
    opened = rng.integers(48, 76, 60)
    closed = opened - rng.integers(0, 7, 60)
    avg_hours = np.round(rng.uniform(3.8, 8.4, 60), 1).astype(object)
    for idx in (7, 23, 41):
        avg_hours[idx] = ""
    sat = np.round(rng.uniform(3.3, 4.8, 60), 2).astype(object)
    for idx in (15, 48):
        sat[idx] = ""
    df = pd.DataFrame({
        "week_start": [d.isoformat() for d in weeks],
        "tickets_opened": opened,
        "tickets_closed": closed,
        "avg_resolution_hours": avg_hours,
        "satisfaction_avg": sat,
        "sla_met_pct": np.round(rng.uniform(82.0, 99.0, 60), 1),
    })
    assert df.shape == (60, 6)
    assert (df["avg_resolution_hours"] == "").sum() == 3
    assert (df["satisfaction_avg"] == "").sum() == 2
    df.to_csv(ASSETS / "chapter-10" / "copperwind_weekly_metrics.csv",
              index=False)
    check = pd.read_csv(
        ASSETS / "chapter-10" / "copperwind_weekly_metrics.csv"
    )
    assert check["avg_resolution_hours"].isna().sum() == 3
    assert check["satisfaction_avg"].isna().sum() == 2
    return df


def build_clients():
    """chapter-11 and chapter-12: 40 nested client records."""
    rng = np.random.default_rng(SEED + 11)
    tiers = ["Basic", "Standard", "Premium"]
    records = []
    for i, (name, industry) in enumerate(CLIENTS, 1):
        seats = int(rng.integers(5, 121))
        tier = tiers[0] if seats < 20 else tiers[1] if seats < 60 else tiers[2]
        records.append({
            "client_id": f"C-{i:03d}",
            "name": name,
            "industry": industry,
            "city": VALLEY_CITIES[int(rng.integers(0, len(VALLEY_CITIES)))],
            "seats": seats,
            "contract": {
                "tier": tier,
                "renewal_year": int(rng.choice([2026, 2027, 2028])),
            },
        })
    assert len(records) == 40
    for folder in ("chapter-11", "chapter-12"):
        with open(ASSETS / folder / "copperwind_clients.json", "w") as fh:
            json.dump(records, fh, indent=2)
            fh.write("\n")
    return records


def build_tickets_q1(clients):
    """chapter-11: 90 Q1 tickets that join to the client list."""
    rng = np.random.default_rng(SEED + 111)
    n = 90
    client_ids = [c["client_id"] for c in clients]
    df = pd.DataFrame({
        "ticket_id": [f"T-{5000 + i}" for i in range(1, n + 1)],
        "opened_date": date_strings(rng, date(2026, 1, 2),
                                    date(2026, 3, 31), n),
        "category": rng.choice(CATEGORIES, n,
                               p=[0.30, 0.27, 0.18, 0.11, 0.14]),
        "priority": rng.choice(PRIORITIES, n,
                               p=[0.25, 0.40, 0.25, 0.10]),
        "client_id": rng.choice(client_ids, n),
        "resolution_hours": np.round(
            np.clip(rng.lognormal(1.1, 0.8, n), 0.3, 30.0), 1
        ),
    })
    assert df.shape == (90, 6)
    assert set(df["client_id"]) <= set(client_ids)
    df.to_csv(ASSETS / "chapter-11" / "copperwind_tickets_q1.csv",
              index=False)
    return df


def build_tickets_full(clients):
    """chapter-12: the full 900 x 11 history with a bias pattern.

    Satisfaction surveys go out when a ticket closes. After-hours
    tickets skip the survey far more often, so their satisfaction is
    missing at roughly 35 percent versus roughly 8 percent for
    business-hours tickets. Chapter 12.1 asks who that silence hides.
    """
    rng = np.random.default_rng(SEED + 12)
    n = 900
    client_ids = [c["client_id"] for c in clients]
    opened = date_strings(rng, date(2024, 1, 2), date(2026, 6, 30), n)
    hours = np.round(np.clip(rng.lognormal(1.15, 0.9, n), 0.3, 60.0), 1)
    closed = [
        (date.fromisoformat(o) + timedelta(days=int(h // 8))).isoformat()
        for o, h in zip(opened, hours)
    ]
    technician = rng.choice(TECH_NAMES, n)
    after_hours = rng.random(n) < 0.30
    satisfaction = rng.choice([1.0, 2.0, 3.0, 4.0, 5.0], n,
                              p=[0.04, 0.08, 0.17, 0.37, 0.34])
    satisfaction = satisfaction.astype(object)
    ah_idx = np.flatnonzero(after_hours)
    bh_idx = np.flatnonzero(~after_hours)
    n_miss_ah = round(0.35 * len(ah_idx))
    n_miss_bh = round(0.08 * len(bh_idx))
    for idx in rng.choice(ah_idx, n_miss_ah, replace=False):
        satisfaction[idx] = ""
    for idx in rng.choice(bh_idx, n_miss_bh, replace=False):
        satisfaction[idx] = ""

    df = pd.DataFrame({
        "ticket_id": [f"T-{10000 + i}" for i in range(1, n + 1)],
        "opened_date": opened,
        "closed_date": closed,
        "category": rng.choice(CATEGORIES, n,
                               p=[0.30, 0.27, 0.18, 0.11, 0.14]),
        "priority": rng.choice(PRIORITIES, n,
                               p=[0.25, 0.40, 0.25, 0.10]),
        "team": [TECH_TEAM[t] for t in technician],
        "technician": technician,
        "client_id": rng.choice(client_ids, n),
        "resolution_hours": hours,
        "satisfaction": satisfaction,
        "after_hours": after_hours,
    })

    assert df.shape == (900, 11)
    assert set(df["client_id"]) <= set(client_ids)
    assert set(df["technician"]) <= set(TECH_NAMES)
    miss = df["satisfaction"] == ""
    rate_ah = miss[df["after_hours"]].mean()
    rate_bh = miss[~df["after_hours"]].mean()
    assert 0.30 <= rate_ah <= 0.40, f"after-hours miss rate {rate_ah:.3f}"
    assert 0.05 <= rate_bh <= 0.11, f"business-hours miss rate {rate_bh:.3f}"

    df.to_csv(ASSETS / "chapter-12" / "copperwind_tickets_full.csv",
              index=False)
    return df


def main():
    build_tickets_january()
    build_tickets_main()
    build_tickets_export()
    build_monthly_volume()
    build_technicians()
    build_sla_study()
    build_weekly_metrics()
    clients = build_clients()
    build_tickets_q1(clients)
    build_tickets_full(clients)
    print("Copperwind datasets generated; all asserts passed.")


if __name__ == "__main__":
    main()
