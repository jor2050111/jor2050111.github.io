"""Generate the synthetic datasets for the CIS215 course data pack.

Every dataset is seeded so regeneration produces byte-identical files.
Each build function documents the pedagogical properties it engineers
(guaranteed missing values, statistically significant group gaps, and
so on) because the Skills Labs depend on them.

Run from anywhere; paths resolve relative to this file:

    python generate_synthetic_datasets.py
"""

import re
import sqlite3
import zipfile
from datetime import datetime
from pathlib import Path

import numpy as np
import pandas as pd

ASSETS = Path(__file__).resolve().parents[1]
SEED = 215  # course number, used as the base seed everywhere


def freeze_zip_times(path):
    """Rewrite an xlsx's zip entry timestamps to a fixed date.

    openpyxl stamps every archive member with the wall clock, so the
    file's bytes drift between runs even when the content is
    identical. Fixed document properties alone do not stop that. This
    rewrite is what makes customers.xlsx byte-identical on rerun.
    """
    src = zipfile.ZipFile(path)
    items = [(zi, src.read(zi.filename)) for zi in src.infolist()]
    src.close()
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as dst:
        for zi, data in items:
            zi.date_time = (2026, 1, 1, 0, 0, 0)
            if zi.filename == "docProps/core.xml":
                # openpyxl stamps dcterms:modified with the wall clock
                # at save time, ignoring the property set beforehand.
                data = re.sub(
                    rb"(<dcterms:modified[^>]*>)[^<]*"
                    rb"(</dcterms:modified>)",
                    rb"\g<1>2026-01-01T00:00:00Z\g<2>",
                    data,
                )
            dst.writestr(zi, data)

MONTH_NAMES = ["January", "February", "March", "April", "May", "June",
               "July", "August", "September", "October", "November",
               "December"]

FIRST_NAMES = [
    "Aaliyah", "Adrian", "Aiden", "Alejandra", "Amara", "Andre",
    "Angel", "Aria", "Ashley", "Brandon", "Brianna", "Carlos",
    "Carmen", "Chloe", "Damian", "Daniela", "Darius", "Denise",
    "Diego", "Elena", "Emily", "Emmanuel", "Fatima", "Gabriel",
    "Grace", "Hana", "Hector", "Imani", "Isaac", "Jasmine",
    "Javier", "Jordan", "Julia", "Kai", "Keisha", "Kevin",
    "Layla", "Leo", "Liliana", "Logan", "Lucia", "Malik",
    "Maria", "Marcus", "Mei", "Miguel", "Naomi", "Nathan",
    "Nina", "Omar", "Priya", "Quinn", "Rafael", "Rosa",
    "Samuel", "Sofia", "Tariq", "Tessa", "Victor", "Zoe",
]

LAST_NAMES = [
    "Anderson", "Baker", "Castillo", "Chen", "Davis", "Flores",
    "Garcia", "Hernandez", "Jackson", "Johnson", "Kim", "Lee",
    "Lopez", "Martinez", "Nguyen", "Ortiz", "Patel", "Ramirez",
    "Smith", "Torres", "Washington", "Williams", "Wilson", "Yazzie",
]


def build_ch02_cafe_sales():
    """Chapter 2: five years of monthly campus cafe financials.

    Engineered so revenue always exceeds expenses (profit stays
    positive), revenue trends upward, and summer months dip because
    the campus empties out. 60 rows x 5 columns.
    """
    rng = np.random.default_rng(SEED + 2)
    rows = []
    for year_index, year in enumerate(range(2021, 2026)):
        for month_index, month in enumerate(MONTH_NAMES):
            # Semester rhythm: strong Feb-Apr and Sep-Nov, weak summer.
            seasonal = [1.00, 1.10, 1.12, 1.08, 0.90, 0.62,
                        0.55, 0.75, 1.10, 1.15, 1.18, 0.95][month_index]
            base = 38000 + year_index * 3500
            revenue = base * seasonal * rng.uniform(0.95, 1.05)
            expenses = revenue * rng.uniform(0.66, 0.78)
            customers = int(revenue / rng.uniform(11.0, 13.5))
            rows.append({
                "year": year,
                "month": month,
                "revenue": round(revenue),
                "expenses": round(expenses),
                "customers_served": customers,
            })
    df_cafe_sales = pd.DataFrame(rows)
    assert (df_cafe_sales["revenue"] > df_cafe_sales["expenses"]).all()
    out = ASSETS / "chapter-02" / "cafe_sales.csv"
    df_cafe_sales.to_csv(out, index=False)
    print(f"{out.name}: {df_cafe_sales.shape}")


def build_ch03_student_grades():
    """Chapter 3: one class roster for the grade-analysis lab.

    Engineered so every letter grade A-F appears, some students land
    below 70 (the tutoring list is never empty), and several score
    above 80 (the list-comprehension filter has matches).
    55 rows x 6 columns.
    """
    rng = np.random.default_rng(SEED + 3)
    n_students = 55
    first_names = list(rng.choice(FIRST_NAMES, n_students,
                                  replace=False))
    majors = rng.choice(
        ["Data Analytics", "Business", "Computer Science",
         "Nursing", "Engineering"],
        n_students,
    )
    exam_scores = np.clip(
        rng.normal(79, 11, n_students), 42, 100
    ).round().astype(int)
    # Pin a few scores so each letter grade band is guaranteed.
    exam_scores[:6] = [95, 91, 88, 74, 63, 55]
    homework_avg = np.clip(
        exam_scores + rng.normal(4, 6, n_students), 50, 100
    ).round(1)
    attendance_pct = np.clip(
        rng.normal(88, 8, n_students), 60, 100
    ).round(1)
    df_grades = pd.DataFrame({
        "student_id": [f"ST{i:03d}" for i in range(1, n_students + 1)],
        "first_name": first_names,
        "major": majors,
        "exam_score": exam_scores,
        "homework_avg": homework_avg,
        "attendance_pct": attendance_pct,
    })
    letters = pd.cut(df_grades["exam_score"],
                     bins=[0, 59, 69, 79, 89, 100],
                     labels=["F", "D", "C", "B", "A"])
    assert set(letters.unique()) == {"A", "B", "C", "D", "F"}
    out = ASSETS / "chapter-03" / "student_grades.csv"
    df_grades.to_csv(out, index=False)
    print(f"{out.name}: {df_grades.shape}")


def build_ch05_ecommerce_orders():
    """Chapter 5: e-commerce orders for the statistics lab.

    Engineered so Price is right-skewed (mean > median, driven by
    laptops), prices come from small discrete sets so the mode is
    meaningful, and regions differ enough for groupby comparisons.
    200 rows x 7 columns.
    """
    rng = np.random.default_rng(SEED + 5)
    n_orders = 200
    catalog = {
        "Laptop": ("Computers", [849.99, 949.99, 1199.99]),
        "Monitor": ("Displays", [249.99, 329.99, 399.99]),
        "Keyboard": ("Accessories", [59.99, 89.99, 119.99]),
        "Mouse": ("Accessories", [24.99, 24.99, 44.99]),
    }
    products = rng.choice(list(catalog), n_orders,
                          p=[0.20, 0.25, 0.25, 0.30])
    regions = rng.choice(["East", "West", "North", "South"], n_orders,
                         p=[0.25, 0.32, 0.18, 0.25])
    dates = pd.Timestamp("2026-01-05") + pd.to_timedelta(
        rng.integers(0, 85, n_orders), unit="D"
    )
    prices = [float(rng.choice(catalog[p][1])) for p in products]
    # The West buys in slightly larger quantities, so regional revenue
    # comparisons in Part 3 have a story to find.
    quantity = np.where(
        regions == "West",
        rng.integers(2, 8, n_orders),
        rng.integers(1, 6, n_orders),
    )
    df_orders = pd.DataFrame({
        "Order_ID": range(1001, 1001 + n_orders),
        "Order_Date": dates.strftime("%Y-%m-%d"),
        "Product": products,
        "Category": [catalog[p][0] for p in products],
        "Price": prices,
        "Quantity": quantity,
        "Region": regions,
    }).sort_values("Order_Date").reset_index(drop=True)
    # A few missing values so .info() has real gaps to reveal
    # (Section 5.1 teaches reading non-null counts).
    df_orders.loc[[52, 147], "Price"] = np.nan
    df_orders.loc[[23, 98, 171], "Order_Date"] = np.nan
    assert df_orders["Price"].mean() > df_orders["Price"].median()
    out = ASSETS / "chapter-05" / "ecommerce_orders.csv"
    df_orders.to_csv(out, index=False)
    print(f"{out.name}: {df_orders.shape}")


def build_ch06_customer_survey():
    """Chapter 6: a survey export with deliberate quality problems.

    Engineered mess, matched to the cleaning tasks in Skills Lab 6A:

    * 5 exact duplicate rows (75 unique responses, 80 total)
    * missing values: 3 names, 6 ages, 5 satisfaction scores
    * Age stored as text (dtype conversion practice)
    * names and store locations with stray case and whitespace
    * Would_Recommend spelled five different ways
    * weekend responses run happier (day-of-week pattern in Part 3)

    80 rows x 7 columns.
    """
    rng = np.random.default_rng(SEED + 6)
    n_unique = 75
    first = rng.choice(FIRST_NAMES, n_unique)
    last = rng.choice(LAST_NAMES, n_unique)
    names = [f"{f} {l}" for f, l in zip(first, last)]

    def mess_up_name(name, style):
        """Apply one of several realistic entry mistakes."""
        return {
            0: name,                    # clean
            1: name.lower(),            # no caps
            2: name.upper(),            # caps lock
            3: f"  {name}",             # leading spaces
            4: f"{name}  ",             # trailing spaces
        }[style]

    styles = rng.integers(0, 5, n_unique)
    names = [mess_up_name(n, s) for n, s in zip(names, styles)]

    dates = pd.Timestamp("2026-02-02") + pd.to_timedelta(
        rng.integers(0, 88, n_unique), unit="D"
    )
    ages = rng.integers(18, 76, n_unique)
    base_satisfaction = rng.choice([1, 2, 3, 3, 4, 4, 4, 5, 5],
                                   n_unique).astype(float)
    # Saturday and Sunday responses trend one point happier.
    weekend = pd.Series(dates).dt.dayofweek >= 5
    satisfaction = np.clip(
        base_satisfaction + np.where(weekend, 1, 0), 1, 5
    )
    stores = rng.choice(
        ["Downtown", "downtown", " Downtown", "Mall", "mall  ",
         "Airport", "AIRPORT"],
        n_unique,
    )
    recommend = rng.choice(
        ["Yes", "yes", "YES", "No", "no"], n_unique
    )

    df_survey = pd.DataFrame({
        "Response_ID": range(1001, 1001 + n_unique),
        "Response_Date": pd.Series(dates).dt.strftime("%Y-%m-%d"),
        "Customer_Name": names,
        "Age": ages.astype(str),
        "Satisfaction": satisfaction,
        "Store_Location": stores,
        "Would_Recommend": recommend,
    })
    # Missing values land on distinct rows so no response loses
    # everything at once.
    df_survey.loc[[4, 21, 47], "Customer_Name"] = np.nan
    df_survey.loc[[7, 15, 30, 41, 58, 66], "Age"] = np.nan
    df_survey.loc[[2, 19, 36, 52, 70], "Satisfaction"] = np.nan
    # Duplicate five completed rows, then shuffle so the copies are
    # not adjacent to their originals.
    dupes = df_survey.iloc[[10, 25, 40, 55, 68]]
    df_survey = pd.concat([df_survey, dupes], ignore_index=True)
    df_survey = df_survey.sample(
        frac=1, random_state=SEED
    ).reset_index(drop=True)
    assert df_survey.duplicated().sum() == 5
    out = ASSETS / "chapter-06" / "customer_survey.csv"
    df_survey.to_csv(out, index=False)
    print(f"{out.name}: {df_survey.shape}")


def build_ch08_regional_sales():
    """Chapter 8: wide-format quarterly sales plus customer reviews.

    The sales file stays wide (Q1-Q4 columns) because melting it to
    long format is the point of the lab. Engineered so Q4 spikes for
    computer products (a seasonal story for the pivot tables) and the
    West region runs strongest. 60 rows x 7 columns.

    The reviews file holds individual reviews that students aggregate
    to product level before merging. Product quality varies so some
    products clear a 4.0 average and others do not.
    90 rows x 5 columns.
    """
    rng = np.random.default_rng(SEED + 8)
    products = {
        "Laptop": ("Computers", 42000), "Desktop": ("Computers", 30000),
        "Tablet": ("Computers", 24000), "Monitor": ("Displays", 21000),
        "Projector": ("Displays", 12000), "Mouse": ("Accessories", 7000),
        "Keyboard": ("Accessories", 8500), "Webcam": ("Accessories", 6500),
        "Headset": ("Audio", 9500), "Speaker": ("Audio", 8000),
        "Microphone": ("Audio", 5500), "Router": ("Networking", 11000),
        "Switch": ("Networking", 7500), "Printer": ("Office", 13000),
        "Scanner": ("Office", 6000),
    }
    region_lift = {"East": 1.10, "West": 1.25,
                   "South": 0.95, "North": 0.85}
    rows = []
    for product, (category, base) in products.items():
        for region, lift in region_lift.items():
            quarters = {}
            for q_index, quarter in enumerate(
                    ["Q1_revenue", "Q2_revenue",
                     "Q3_revenue", "Q4_revenue"]):
                seasonal = [1.00, 0.95, 0.90, 1.10][q_index]
                if category == "Computers" and quarter == "Q4_revenue":
                    seasonal = 1.45  # holiday electronics spike
                value = base * lift * seasonal * rng.uniform(0.85, 1.15)
                quarters[quarter] = round(value)
            rows.append({"product": product, "category": category,
                         "region": region, **quarters})
    df_sales_regional = pd.DataFrame(rows)
    out = ASSETS / "chapter-08" / "regional_sales.csv"
    df_sales_regional.to_csv(out, index=False)
    print(f"{out.name}: {df_sales_regional.shape}")

    # Reviews: 6 per product, quality varies by product.
    quality = {p: rng.uniform(3.2, 4.7) for p in products}
    review_rows = []
    review_id = 5001
    for product in products:
        for _ in range(6):
            rating = int(np.clip(
                round(rng.normal(quality[product], 0.7)), 1, 5
            ))
            review_rows.append({
                "review_id": review_id,
                "product": product,
                "rating": rating,
                "verified_purchase": bool(rng.random() < 0.7),
                "review_date": (
                    pd.Timestamp("2026-01-10")
                    + pd.Timedelta(days=int(rng.integers(0, 140)))
                ).strftime("%Y-%m-%d"),
            })
            review_id += 1
    df_reviews = pd.DataFrame(review_rows)
    mean_ratings = df_reviews.groupby("product")["rating"].mean()
    assert (mean_ratings > 4.0).any() and (mean_ratings <= 4.0).any()
    out = ASSETS / "chapter-08" / "customer_reviews.csv"
    df_reviews.to_csv(out, index=False)
    print(f"{out.name}: {df_reviews.shape}")


def build_ch09_student_performance():
    """Chapter 9: education data with engineered statistical results.

    Guarantees, verified by the asserts below:

    * StudyHours is the strongest MathScore correlate (about 0.65)
    * the Gender t-test is NOT significant (scores were built with no
      gender effect; the lab lesson is reading a null result honestly)
    * the TeachingMethod t-test IS significant (Interactive +7)
    * StudyCategory x PassFail chi-square is significant
    * every StudyCategory (Low/Medium/High) is populated

    200 rows x 7 columns.
    """
    rng = np.random.default_rng(SEED + 9)
    n_students = 200
    study_hours = rng.integers(2, 25, n_students)
    attendance = rng.integers(50, 100, n_students)
    prior_gpa = rng.uniform(2.0, 4.0, n_students).round(2)
    gender = rng.choice(["Male", "Female"], n_students)
    method = rng.choice(["Traditional", "Interactive"], n_students)
    math_score = (
        30
        + study_hours * 1.2
        + attendance * 0.15
        + prior_gpa * 5.5
        + np.where(method == "Interactive", 7, 0)
        + rng.normal(0, 7, n_students)
    )
    math_score = np.clip(math_score, 45, 100).round().astype(int)
    df_students = pd.DataFrame({
        "StudentID": range(1, n_students + 1),
        "StudyHours": study_hours,
        "AttendanceRate": attendance,
        "PriorGPA": prior_gpa,
        "MathScore": math_score,
        "Gender": gender,
        "TeachingMethod": method,
    })

    def t_statistic(a, b):
        """Welch's t without scipy (verification only)."""
        va, vb = a.var(ddof=1), b.var(ddof=1)
        return (a.mean() - b.mean()) / np.sqrt(
            va / len(a) + vb / len(b)
        )

    corr = df_students["StudyHours"].corr(df_students["MathScore"])
    assert 0.55 < corr < 0.75, f"StudyHours corr off target: {corr:.2f}"
    t_gender = t_statistic(
        df_students.loc[df_students["Gender"] == "Male", "MathScore"],
        df_students.loc[df_students["Gender"] == "Female", "MathScore"],
    )
    assert abs(t_gender) < 1.5, f"gender gap too large: t={t_gender:.2f}"
    t_method = t_statistic(
        df_students.loc[
            df_students["TeachingMethod"] == "Interactive", "MathScore"
        ],
        df_students.loc[
            df_students["TeachingMethod"] == "Traditional", "MathScore"
        ],
    )
    assert t_method > 3.0, f"method effect too weak: t={t_method:.2f}"
    category = pd.cut(df_students["StudyHours"], bins=[0, 9, 17, 24],
                      labels=["Low", "Medium", "High"])
    passed = df_students["MathScore"] >= 70
    table = pd.crosstab(category, passed)
    expected = (
        np.outer(table.sum(axis=1), table.sum(axis=0))
        / table.values.sum()
    )
    chi2 = ((table.values - expected) ** 2 / expected).sum()
    assert chi2 > 9.21, f"chi-square too weak: {chi2:.2f}"  # p<.01, df=2
    assert category.value_counts().min() > 20

    out = ASSETS / "chapter-09" / "student_performance.csv"
    df_students.to_csv(out, index=False)
    print(f"{out.name}: {df_students.shape} | corr={corr:.2f} "
          f"t_gender={t_gender:.2f} t_method={t_method:.2f} "
          f"chi2={chi2:.1f}")


def build_ch10_monthly_sales():
    """Chapter 10: five years of monthly sales for the functions lab.

    Two Expenses values are deliberately missing so the student's
    clean_sales_data() function has real work to do, and Q4 runs
    strongest so summarize_by_quarter() finds a clear top quarter.
    60 rows x 5 columns.
    """
    rng = np.random.default_rng(SEED + 10)
    rows = []
    for year_index, year in enumerate(range(2021, 2026)):
        for month_num in range(1, 13):
            seasonal = [0.92, 0.90, 0.98, 1.00, 1.02, 1.05,
                        1.03, 1.06, 1.00, 1.04, 1.12, 1.25][month_num - 1]
            base = 52000 + year_index * 6000
            revenue = base * seasonal * rng.uniform(0.95, 1.05)
            expenses = revenue * rng.uniform(0.62, 0.74)
            units = int(revenue / rng.uniform(95, 115))
            marketing = round(revenue * rng.uniform(0.05, 0.09))
            rows.append({
                "Month": f"{year}-{month_num:02d}",
                "Revenue": round(revenue),
                "Expenses": round(expenses),
                "Units_Sold": units,
                "Marketing_Spend": marketing,
            })
    df_sales_monthly = pd.DataFrame(rows)
    # Missing expenses in two mid-series months (cleaning practice).
    df_sales_monthly.loc[
        df_sales_monthly["Month"].isin(["2022-03", "2024-07"]),
        "Expenses",
    ] = np.nan
    assert df_sales_monthly["Expenses"].isna().sum() == 2
    out = ASSETS / "chapter-10" / "monthly_sales.csv"
    df_sales_monthly.to_csv(out, index=False)
    print(f"{out.name}: {df_sales_monthly.shape}")


def build_ch11_multi_source():
    """Chapter 11: linked CSV, JSON, and Excel sources.

    All three files share keys (product_id joins sales to the catalog)
    so the lab's merge produces clean matches. 300 sales rows,
    50 catalog products, 60 customers.
    """
    rng = np.random.default_rng(SEED + 11)

    adjectives = ["Pro", "Lite", "Max", "Mini", "Ultra"]
    nouns = ["Widget", "Gadget", "Sensor", "Module", "Adapter",
             "Bracket", "Panel", "Switch", "Cable", "Mount"]
    categories = ["Hardware", "Electronics", "Tools",
                  "Materials", "Safety"]
    suppliers = ["Acme Supply", "Desert Distributors", "Cactus Corp",
                 "Northline Trading", "Valley Wholesale"]
    catalog_rows = []
    for product_id in range(1, 51):
        name = (f"{rng.choice(adjectives)} "
                f"{rng.choice(nouns)} {product_id}")
        catalog_rows.append({
            "product_id": product_id,
            "name": name,
            "category": str(rng.choice(categories)),
            "unit_price": round(float(rng.uniform(4, 250)), 2),
            "supplier": str(rng.choice(suppliers)),
        })
    df_products = pd.DataFrame(catalog_rows)
    out_json = ASSETS / "chapter-11" / "products.json"
    df_products.to_json(out_json, orient="records", indent=2)
    print(f"{out_json.name}: {df_products.shape}")

    n_sales = 300
    product_ids = rng.integers(1, 51, n_sales)
    unit_prices = df_products.set_index("product_id").loc[
        product_ids, "unit_price"
    ].to_numpy()
    df_retail = pd.DataFrame({
        "sale_id": range(20001, 20001 + n_sales),
        "date": (
            pd.Timestamp("2026-01-05")
            + pd.to_timedelta(rng.integers(0, 170, n_sales), unit="D")
        ).strftime("%Y-%m-%d"),
        "product_id": product_ids,
        "quantity": rng.integers(1, 9, n_sales),
        "price": unit_prices,
    }).sort_values("date").reset_index(drop=True)
    out_csv = ASSETS / "chapter-11" / "retail_sales.csv"
    df_retail.to_csv(out_csv, index=False)
    print(f"{out_csv.name}: {df_retail.shape}")

    n_customers = 60
    first = rng.choice(FIRST_NAMES, n_customers)
    last = rng.choice(LAST_NAMES, n_customers)
    states = rng.choice(
        ["AZ", "AZ", "AZ", "CA", "NV", "NM", "TX", "CO", "UT"],
        n_customers,
    )
    cities = {"AZ": "Phoenix", "CA": "San Diego", "NV": "Las Vegas",
              "NM": "Albuquerque", "TX": "El Paso", "CO": "Denver",
              "UT": "Salt Lake City"}
    df_customers = pd.DataFrame({
        "customer_id": range(101, 101 + n_customers),
        "name": [f"{f} {l}" for f, l in zip(first, last)],
        "city": [cities[s] for s in states],
        "state": states,
        "signup_date": (
            pd.Timestamp("2024-01-15")
            + pd.to_timedelta(rng.integers(0, 800, n_customers),
                              unit="D")
        ).strftime("%Y-%m-%d"),
    })
    out_xlsx = ASSETS / "chapter-11" / "customers.xlsx"
    with pd.ExcelWriter(out_xlsx, engine="openpyxl") as writer:
        df_customers.to_excel(writer, index=False,
                              sheet_name="Customers")
        # openpyxl stamps "now" into the document properties, which
        # made the file drift by a byte on every rerun. A fixed stamp
        # keeps the xlsx byte-identical.
        stamp = datetime(2026, 1, 1)
        writer.book.properties.created = stamp
        writer.book.properties.modified = stamp
    freeze_zip_times(out_xlsx)
    print(f"{out_xlsx.name}: {df_customers.shape}")

    # SQLite mirror of the same linked sources, so chapter 11 can run
    # real SQL locally with the stdlib driver instead of only reading
    # about server databases.
    out_db = ASSETS / "chapter-11" / "store.db"
    out_db.unlink(missing_ok=True)
    conn = sqlite3.connect(out_db)
    df_products.to_sql("products", conn, index=False)
    df_retail.to_sql("sales", conn, index=False)
    df_customers.to_sql("customers", conn, index=False)
    conn.commit()
    counts = {t: conn.execute(f"SELECT COUNT(*) FROM {t}").fetchone()[0]
              for t in ("products", "sales", "customers")}
    conn.close()
    assert counts == {"products": 50, "sales": 300, "customers": 60}
    print(f"{out_db.name}: {counts}")


def main():
    build_ch02_cafe_sales()
    build_ch03_student_grades()
    build_ch05_ecommerce_orders()
    build_ch06_customer_survey()
    build_ch08_regional_sales()
    build_ch09_student_performance()
    build_ch10_monthly_sales()
    build_ch11_multi_source()


if __name__ == "__main__":
    main()
