"""Prepare the real (public) datasets for the CIS215 course data pack.

Downloads public source data and writes the course-ready files:

* chapter-01/gapminder.csv      -- Gapminder five-year data (plotly copy)
* chapter-04/city_populations.csv -- 60 largest US cities (plotly copy of
                                     US Census estimates)
* chapter-07/city_temperatures.csv -- NOAA 1991-2020 climate normals,
                                      transcribed and rounded
* chapter-11/states_table.html  -- offline fallback for the Wikipedia
                                   states-by-population table
* chapter-12/penguins.csv       -- Palmer Penguins (CC0, seaborn-data copy)

Run from anywhere; paths resolve relative to this file. Pass a cache
directory as the first argument to reuse already-downloaded raw files:

    python prepare_real_datasets.py /path/to/cache
"""

import sys
import urllib.request
from pathlib import Path

import pandas as pd

ASSETS = Path(__file__).resolve().parents[1]

GAPMINDER_URL = "https://raw.githubusercontent.com/plotly/datasets/master/gapminderDataFiveYear.csv"  # noqa: E501
CITIES_URL = "https://raw.githubusercontent.com/plotly/datasets/master/us-cities-top-1k.csv"  # noqa: E501
PENGUINS_URL = "https://raw.githubusercontent.com/mwaskom/seaborn-data/master/penguins.csv"  # noqa: E501
STATES_URL = "https://en.wikipedia.org/wiki/List_of_U.S._states_and_territories_by_population"  # noqa: E501

# US Census Bureau four-region classification, keyed by full state name
# because the plotly cities file spells states out.
CENSUS_REGIONS = {
    "Connecticut": "Northeast", "Maine": "Northeast",
    "Massachusetts": "Northeast", "New Hampshire": "Northeast",
    "Rhode Island": "Northeast", "Vermont": "Northeast",
    "New Jersey": "Northeast", "New York": "Northeast",
    "Pennsylvania": "Northeast",
    "Illinois": "Midwest", "Indiana": "Midwest", "Michigan": "Midwest",
    "Ohio": "Midwest", "Wisconsin": "Midwest", "Iowa": "Midwest",
    "Kansas": "Midwest", "Minnesota": "Midwest", "Missouri": "Midwest",
    "Nebraska": "Midwest", "North Dakota": "Midwest",
    "South Dakota": "Midwest",
    "Delaware": "South", "Florida": "South", "Georgia": "South",
    "Maryland": "South", "North Carolina": "South",
    "South Carolina": "South", "Virginia": "South",
    "District of Columbia": "South", "West Virginia": "South",
    "Alabama": "South", "Kentucky": "South", "Mississippi": "South",
    "Tennessee": "South", "Arkansas": "South", "Louisiana": "South",
    "Oklahoma": "South", "Texas": "South",
    "Arizona": "West", "Colorado": "West", "Idaho": "West",
    "Montana": "West", "Nevada": "West", "New Mexico": "West",
    "Utah": "West", "Wyoming": "West", "Alaska": "West",
    "California": "West", "Hawaii": "West", "Oregon": "West",
    "Washington": "West",
}

STATE_ABBREV = {
    "Alabama": "AL", "Alaska": "AK", "Arizona": "AZ", "Arkansas": "AR",
    "California": "CA", "Colorado": "CO", "Connecticut": "CT",
    "Delaware": "DE", "District of Columbia": "DC", "Florida": "FL",
    "Georgia": "GA", "Hawaii": "HI", "Idaho": "ID", "Illinois": "IL",
    "Indiana": "IN", "Iowa": "IA", "Kansas": "KS", "Kentucky": "KY",
    "Louisiana": "LA", "Maine": "ME", "Maryland": "MD",
    "Massachusetts": "MA", "Michigan": "MI", "Minnesota": "MN",
    "Mississippi": "MS", "Missouri": "MO", "Montana": "MT",
    "Nebraska": "NE", "Nevada": "NV", "New Hampshire": "NH",
    "New Jersey": "NJ", "New Mexico": "NM", "New York": "NY",
    "North Carolina": "NC", "North Dakota": "ND", "Ohio": "OH",
    "Oklahoma": "OK", "Oregon": "OR", "Pennsylvania": "PA",
    "Rhode Island": "RI", "South Carolina": "SC", "South Dakota": "SD",
    "Tennessee": "TN", "Texas": "TX", "Utah": "UT", "Vermont": "VT",
    "Virginia": "VA", "Washington": "WA", "West Virginia": "WV",
    "Wisconsin": "WI", "Wyoming": "WY",
}

# NOAA 1991-2020 US Climate Normals, transcribed and rounded to one
# decimal. Monthly average high (F), average low (F), and precipitation
# (inches) for five stations chosen to contrast desert, coastal,
# continental, and tropical climates.
CLIMATE_NORMALS = {
    "Phoenix": {
        "high": [67.2, 70.7, 76.9, 85.2, 94.8, 104.6,
                 106.5, 104.8, 100.5, 89.4, 76.5, 66.2],
        "low": [46.0, 48.7, 53.7, 60.6, 69.5, 78.5,
                84.5, 83.9, 78.0, 66.4, 54.5, 45.6],
        "precip": [0.87, 0.90, 0.83, 0.25, 0.14, 0.02,
                   0.94, 0.99, 0.60, 0.58, 0.57, 0.94],
    },
    "New York": {
        "high": [39.5, 42.2, 49.9, 61.8, 71.4, 79.7,
                 84.9, 83.3, 76.2, 64.5, 54.0, 44.3],
        "low": [27.9, 29.5, 35.8, 45.5, 55.0, 64.4,
                70.1, 69.0, 62.3, 50.9, 41.5, 33.4],
        "precip": [3.64, 3.19, 4.29, 4.09, 3.96, 4.54,
                   4.60, 4.56, 4.31, 4.38, 3.58, 4.38],
    },
    "Chicago": {
        "high": [32.8, 36.2, 47.0, 59.0, 70.5, 80.4,
                 84.5, 82.5, 76.1, 62.9, 49.1, 37.4],
        "low": [19.5, 22.7, 31.9, 42.1, 52.6, 62.7,
                68.1, 66.8, 59.1, 47.1, 36.1, 25.3],
        "precip": [2.30, 2.12, 2.66, 3.86, 4.66, 4.19,
                   3.91, 4.00, 3.31, 3.68, 2.49, 2.42],
    },
    "Los Angeles": {
        "high": [68.0, 68.4, 70.0, 72.6, 74.7, 78.4,
                 83.1, 84.6, 83.1, 78.6, 72.9, 67.6],
        "low": [48.7, 49.8, 52.0, 54.5, 58.2, 61.5,
                64.9, 65.7, 64.3, 59.8, 52.9, 48.0],
        "precip": [3.29, 3.64, 2.23, 0.69, 0.32, 0.09,
                   0.02, 0.00, 0.13, 0.58, 0.78, 2.48],
    },
    "Miami": {
        "high": [76.4, 78.7, 80.9, 84.2, 87.6, 90.0,
                 91.4, 91.4, 89.6, 86.3, 81.6, 78.3],
        "low": [61.7, 63.9, 66.5, 70.3, 74.3, 77.2,
                78.5, 78.6, 77.6, 74.6, 68.9, 64.9],
        "precip": [1.62, 2.25, 2.99, 3.14, 5.34, 10.52,
                   7.05, 8.67, 9.86, 7.02, 3.43, 2.16],
    },
}

MONTH_NAMES = ["January", "February", "March", "April", "May", "June",
               "July", "August", "September", "October", "November",
               "December"]


def fetch(url, cache_dir, filename):
    """Return a local path for url, downloading unless cached."""
    if cache_dir is not None:
        cached = Path(cache_dir) / filename
        if cached.exists():
            return cached
    target = Path("/tmp") / filename
    request = urllib.request.Request(
        url, headers={"User-Agent": "Mozilla/5.0 (CIS215 course build)"}
    )
    with urllib.request.urlopen(request, timeout=60) as response:
        target.write_bytes(response.read())
    return target


def build_gapminder(cache_dir):
    """Copy the plotly Gapminder file verbatim into chapter 1."""
    source = fetch(GAPMINDER_URL, cache_dir, "gapminder_full.csv")
    df_gapminder = pd.read_csv(source)
    out = ASSETS / "chapter-01" / "gapminder.csv"
    df_gapminder.to_csv(out, index=False)
    print(f"{out.name}: {df_gapminder.shape}")


def build_city_populations(cache_dir):
    """Top 60 US cities by population with Census regions."""
    source = fetch(CITIES_URL, cache_dir, "us_cities_1k.csv")
    df_cities = pd.read_csv(source)
    df_cities = (
        df_cities.sort_values("Population", ascending=False)
        .head(60)
        .reset_index(drop=True)
    )
    df_cities["Region"] = df_cities["State"].map(CENSUS_REGIONS)
    df_cities["State"] = df_cities["State"].map(STATE_ABBREV)
    df_cities = df_cities.rename(columns={"lat": "Lat", "lon": "Lon"})
    df_cities = df_cities[
        ["City", "State", "Population", "Region", "Lat", "Lon"]
    ]
    assert df_cities["Region"].notna().all(), "unmapped state found"
    out = ASSETS / "chapter-04" / "city_populations.csv"
    df_cities.to_csv(out, index=False)
    print(f"{out.name}: {df_cities.shape}")


def build_city_temperatures():
    """Long-format monthly climate normals for five cities."""
    rows = []
    for city, normals in CLIMATE_NORMALS.items():
        for i in range(12):
            rows.append({
                "City": city,
                "Month_Num": i + 1,
                "Month_Name": MONTH_NAMES[i],
                "Avg_High_F": normals["high"][i],
                "Avg_Low_F": normals["low"][i],
                "Precip_In": normals["precip"][i],
            })
    df_temps = pd.DataFrame(rows)
    out = ASSETS / "chapter-07" / "city_temperatures.csv"
    df_temps.to_csv(out, index=False)
    print(f"{out.name}: {df_temps.shape}")


def build_penguins(cache_dir):
    """Copy the Palmer Penguins file verbatim into chapter 12."""
    source = fetch(PENGUINS_URL, cache_dir, "penguins.csv")
    df_penguins = pd.read_csv(source)
    out = ASSETS / "chapter-12" / "penguins.csv"
    df_penguins.to_csv(out, index=False)
    print(f"{out.name}: {df_penguins.shape}")


def build_states_table(cache_dir):
    """Save an offline copy of the Wikipedia states table.

    The live page is the primary Skills Lab 11A target; this file keeps
    the lab working if the page layout changes or internet drops.
    """
    source = fetch(STATES_URL, cache_dir, "wiki_states.html")
    tables = pd.read_html(source)
    df_states = tables[0]
    # The Wikipedia table uses two header rows; flatten to the second.
    df_states.columns = [
        col[1] if isinstance(col, tuple) else col
        for col in df_states.columns
    ]
    keep = df_states.columns[[1, 2, 3, 4]]
    df_states = df_states[keep]
    df_states.columns = [
        "State", "Population_2025_Est", "Population_2020_Census",
        "House_Seats",
    ]
    # Keep only the 50 states; territories carry footnote rows that
    # would break numeric conversion for students.
    df_states = df_states[df_states["State"].isin(STATE_ABBREV)]
    df_states = df_states.reset_index(drop=True)
    out = ASSETS / "chapter-11" / "states_table.html"
    html = df_states.to_html(index=False)
    out.write_text(
        "<html><head><title>US States by Population"
        "</title></head><body>\n"
        "<h1>US States by Population</h1>\n"
        "<p>Offline copy of the Wikipedia table 'List of U.S. states "
        "and territories by population', simplified for classroom "
        "use.</p>\n" + html + "\n</body></html>\n"
    )
    print(f"{out.name}: {df_states.shape}")


def main():
    cache_dir = sys.argv[1] if len(sys.argv) > 1 else None
    build_gapminder(cache_dir)
    build_city_populations(cache_dir)
    build_city_temperatures()
    build_penguins(cache_dir)
    build_states_table(cache_dir)


if __name__ == "__main__":
    main()
