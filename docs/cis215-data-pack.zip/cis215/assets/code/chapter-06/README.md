# Chapter 6 Data

## customer_survey.csv

A customer satisfaction survey export with deliberate data quality
problems, built for the cleaning Skills Lab 6A. 80 rows, 7 columns
(75 unique responses plus 5 exact duplicates).

| Column | Type | Description |
|--------|------|-------------|
| Response_ID | integer | Survey response ID (duplicated rows repeat it) |
| Response_Date | date | Response date (spring 2026) |
| Customer_Name | text | Respondent name; messy case and whitespace |
| Age | number | Respondent age; missing values force float dtype |
| Satisfaction | float | Satisfaction score, 1-5 scale |
| Store_Location | text | Store; inconsistent case and whitespace |
| Would_Recommend | text | Yes/No spelled several inconsistent ways |

Engineered quality problems, matched to the lab tasks:

* 5 exact duplicate rows
* Missing values: 3 names, 6 ages, 5 satisfaction scores
* Inconsistent capitalization and stray whitespace in
  `Customer_Name`, `Store_Location`, and `Would_Recommend`
* Weekend responses average about one point happier, so the
  day-of-week analysis in Part 3 finds a real pattern

**Load from the data pack root:**

```python
df_survey = pd.read_csv('assets/code/chapter-06/customer_survey.csv')
```

**Source:** Synthetic, generated with a fixed seed by
`_generators/generate_synthetic_datasets.py`. All names are fictional.

## copperwind_tickets_export.csv

A deliberately messy ticket export from Copperwind's old help desk
tool, used in Try It Yourself 6.5. Engineered mess, verified by the
generator: 6 fully duplicated rows, at least 8 raw spellings of the
five category values (case and whitespace chaos), 12 missing
satisfaction values, and 5 'pending' strings in resolution_hours that
force the column to load as text. 110 rows, 6 columns.

| Column | Type | Description |
|--------|------|-------------|
| ticket_id | text | Ticket identifier (duplicates exist by design) |
| opened_date | date | Date opened, January-February 2026 |
| category | text | Category with case and whitespace chaos |
| priority | text | Low, Medium, High, or Critical |
| resolution_hours | text | Hours, plus 'pending' for open tickets |
| satisfaction | float | Client survey score 1-5, 12 values missing |

**Load from the data pack root:**

```python
df_export = pd.read_csv(
    'assets/code/chapter-06/copperwind_tickets_export.csv'
)
```

**Source:** Seeded synthetic data from
`_generators/generate_copperwind_data.py` (base seed 215,
byte-identical on rerun). Copperwind IT Services is a fictional
company created for this textbook. All names, clients, and
records are synthetic. Any resemblance to a real company or
person is coincidental.
