# Chapter 3 Data

## student_grades.csv

A class roster of 55 students for the grade-analysis Skills Lab 3A.
55 rows, 6 columns.

| Column | Type | Description |
|--------|------|-------------|
| student_id | text | Unique ID (ST001-ST055) |
| first_name | text | Student first name |
| major | text | Declared major (5 programs) |
| exam_score | integer | Exam score, 0-100 scale |
| homework_avg | float | Homework average, 0-100 scale |
| attendance_pct | float | Attendance percentage |

Every letter grade A-F appears in `exam_score`, several students
score below 70, and several score above 80, so every lab task has
matching rows.

**Load from the data pack root:**

```python
df_grades = pd.read_csv('assets/code/chapter-03/student_grades.csv')
```

**Source:** Synthetic, generated with a fixed seed by
`_generators/generate_synthetic_datasets.py`. All names are fictional.

## gapminder_sample.csv

A curated 20-row Gapminder subset used by the Section 5 draft
examples (not the Skills Lab). The "GDP per Capita" column keeps its
space on purpose to teach bracket notation. Columns: Year, Country,
LifeExp, Population, GDP per Capita.

**Source:** Gapminder Foundation data (CC BY 4.0), subset from the
plotly/datasets copy.
