# Chapter 9 Data

## student_performance.csv

Student study habits and outcomes for the statistical analysis
Skills Lab 9A. 200 rows, 7 columns.

| Column | Type | Description |
|--------|------|-------------|
| StudentID | integer | Unique student ID (1-200) |
| StudyHours | integer | Weekly study hours (2-24) |
| AttendanceRate | integer | Attendance percentage (50-99) |
| PriorGPA | float | GPA before the course (2.00-4.00) |
| MathScore | integer | Final math score (45-100) |
| Gender | text | Male or Female |
| TeachingMethod | text | Traditional or Interactive |

Engineered statistical properties, verified by the generator:

* `StudyHours` is the strongest correlate of `MathScore`
  (about 0.64), with `PriorGPA` and `AttendanceRate` weaker
* The Gender t-test is NOT significant; scores were generated with
  no gender effect, so the honest conclusion is a null result
* The TeachingMethod t-test IS significant (Interactive scores about
  7 points higher)
* The StudyCategory x PassFail chi-square test is significant, and
  all three study categories (Low, Medium, High) are well populated

**Load from the data pack root:**

```python
df_students = pd.read_csv(
    'assets/code/chapter-09/student_performance.csv'
)
```

**Source:** Synthetic, generated with a fixed seed for this textbook.
All records are fictional; the dataset contains no real student
information.

## copperwind_sla_study.csv

Copperwind's triage process study, used in Try It Yourself 9.4 and
Fix It 9.1. The company ran 80 tickets under the Old triage process
and 80 under the New one. Engineered and verified by the generator:
the resolution-hours t-test is significant (the New process is
faster), the satisfaction t-test is a genuine null (both groups share
the same score distribution), and exactly 6 satisfaction values are
missing so a t-test that ignores them returns nan instead of raising.
160 rows, 6 columns.

| Column | Type | Description |
|--------|------|-------------|
| ticket_id | text | Ticket identifier (S-101 to S-260) |
| process | text | Old or New triage process, 80 tickets each |
| resolution_hours | float | Hours from open to close |
| category | text | Hardware, Software, Network, Security, or Accounts |
| first_response_minutes | integer | Minutes to first response |
| satisfaction | float | Client survey score 1-5, 6 values missing |

**Load from the data pack root:**

```python
df_sla = pd.read_csv('assets/code/chapter-09/copperwind_sla_study.csv')
```

**Source:** Seeded synthetic data generated for this textbook (base
seed 215, byte-identical on rerun). Copperwind IT Services is a
fictional company created for this textbook. All names, clients, and
records are synthetic. Any resemblance to a real company or person is
coincidental.
