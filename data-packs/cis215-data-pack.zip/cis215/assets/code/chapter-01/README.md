# Chapter 1 Data

## gapminder.csv

Global development indicators for 142 countries, recorded every five
years from 1952 to 2007. Used in the Chapter 1 examples and Skills
Lab 1A. 1,704 rows, 6 columns.

| Column | Type | Description |
|--------|------|-------------|
| country | text | Country name |
| year | integer | Observation year (1952-2007, every 5 years) |
| pop | float | Total population |
| continent | text | Continent name |
| lifeExp | float | Life expectancy at birth, in years |
| gdpPercap | float | GDP per capita, inflation-adjusted US dollars |

**Load from the data pack root:**

```python
df_gapminder = pd.read_csv('assets/code/chapter-01/gapminder.csv')
```

**Source:** Gapminder Foundation data, distributed through the
plotly/datasets repository (gapminderDataFiveYear.csv). Free for use
with attribution (CC BY 4.0).

## copperwind_tickets_january.csv

One month of support tickets from Copperwind IT Services, the
fictional Phoenix managed-services company that appears throughout
this book. Used in Try It Yourself 1.5 for a first look at loading
and inspecting data. 60 rows, 6 columns.

| Column | Type | Description |
|--------|------|-------------|
| ticket_id | text | Ticket identifier (T-2601 to T-2660) |
| opened_date | date | Date opened, January 2026 |
| category | text | Hardware, Software, Network, Security, or Accounts |
| priority | text | Low, Medium, High, or Critical |
| resolution_hours | float | Hours from open to close |
| satisfaction | integer | Client survey score, 1-5 |

**Load from the data pack root:**

```python
df_tickets = pd.read_csv(
    'assets/code/chapter-01/copperwind_tickets_january.csv'
)
```

**Source:** Seeded synthetic data generated for this textbook (base
seed 215, byte-identical on rerun). Copperwind IT Services is a
fictional company created for this textbook. All names, clients, and
records are synthetic. Any resemblance to a real company or person is
coincidental.
