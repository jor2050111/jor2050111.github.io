# Chapter 5 Data

## ecommerce_orders.csv

A quarter of e-commerce order records for the statistics Skills
Lab 5A. 200 rows, 7 columns.

| Column | Type | Description |
|--------|------|-------------|
| Order_ID | integer | Unique order number |
| Order_Date | date | Order date (2026 Q1) |
| Product | text | Laptop, Monitor, Keyboard, or Mouse |
| Category | text | Computers, Displays, or Accessories |
| Price | float | Unit price in US dollars |
| Quantity | integer | Units ordered |
| Region | text | East, West, North, or South |

Engineered properties the lab depends on: `Price` is right-skewed
(mean well above median, pulled by laptops), prices come from small
discrete sets so the mode is meaningful, and the West region orders
larger quantities so regional comparisons show a clear pattern.

**Load from the data pack root:**

```python
df_orders = pd.read_csv('assets/code/chapter-05/ecommerce_orders.csv')
```

**Source:** Synthetic, generated with a fixed seed for this textbook.

## copperwind_tickets.csv

The same six-month Copperwind ticket file that appears in Chapter 4,
shipped here so this chapter stands alone. Used in Try It Yourself
5.3. The resolution_hours column is right-skewed by design (a few
long outages pull the mean well above the median), so the mean-versus-
median comparison has a clear answer. 200 rows, 7 columns.

| Column | Type | Description |
|--------|------|-------------|
| ticket_id | text | Ticket identifier (T-1001 to T-1200) |
| opened_date | date | Date opened, January-June 2026 |
| category | text | Hardware, Software, Network, Security, or Accounts |
| priority | text | Low, Medium, High, or Critical |
| technician | text | Assigned technician |
| team | text | Deskside or Network Ops |
| resolution_hours | float | Hours from open to close, right-skewed |

**Load from the data pack root:**

```python
df_tickets = pd.read_csv('assets/code/chapter-05/copperwind_tickets.csv')
```

**Source:** Seeded synthetic data generated for this textbook (base
seed 215, byte-identical on rerun). Copperwind IT Services is a
fictional company created for this textbook. All names, clients, and
records are synthetic. Any resemblance to a real company or person is
coincidental.
