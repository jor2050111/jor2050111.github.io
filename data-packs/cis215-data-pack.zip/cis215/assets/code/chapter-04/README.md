# Chapter 4 Data

## city_populations.csv

The 60 most populous US cities with US Census regions, sorted by
population in descending order. Used in Skills Lab 4A. 60 rows,
6 columns.

| Column | Type | Description |
|--------|------|-------------|
| City | text | City name |
| State | text | Two-letter state abbreviation |
| Population | integer | City population estimate |
| Region | text | US Census region (Northeast, Midwest, South, West) |
| Lat | float | Latitude of city center |
| Lon | float | Longitude of city center |

The file arrives sorted by `Population` descending with a fresh
0-based index, so `.loc[0:4]` selects the five largest cities.

**Load from the data pack root:**

```python
df_cities = pd.read_csv('assets/code/chapter-04/city_populations.csv')
```

**Source:** plotly/datasets `us-cities-top-1k.csv`, derived from US
Census Bureau population estimates; Census region and state
abbreviation columns added during preparation. Public data.

## copperwind_tickets.csv

Six months of Copperwind support tickets. Used in Try It Yourself 4.4
to practice boolean filtering. The counts behind the exercise are
engineered and verified by the generator: 12 Critical tickets, 38
Network tickets, 4 Critical Network tickets, and 11 Network tickets
over 8 resolution hours. 200 rows, 7 columns.

| Column | Type | Description |
|--------|------|-------------|
| ticket_id | text | Ticket identifier (T-1001 to T-1200) |
| opened_date | date | Date opened, January-June 2026 |
| category | text | Hardware, Software, Network, Security, or Accounts |
| priority | text | Low, Medium, High, or Critical |
| technician | text | Assigned technician |
| team | text | Deskside or Network Ops |
| resolution_hours | float | Hours from open to close, right-skewed |

**Load from the data pack root:**

```python
df_tickets = pd.read_csv('assets/code/chapter-04/copperwind_tickets.csv')
```

**Source:** Seeded synthetic data generated for this textbook (base
seed 215, byte-identical on rerun). Copperwind IT Services is a
fictional company created for this textbook. All names, clients, and
records are synthetic. Any resemblance to a real company or person is
coincidental.
