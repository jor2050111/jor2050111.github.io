# Chapter 10 Data

## monthly_sales.csv

Five years of monthly company sales (2021-2025) for the reusable
functions Skills Lab 10A. 60 rows, 5 columns.

| Column | Type | Description |
|--------|------|-------------|
| Month | text | Year-month string (2021-01 through 2025-12) |
| Revenue | integer | Monthly revenue, US dollars |
| Expenses | integer | Monthly expenses, US dollars; 2 values missing |
| Units_Sold | integer | Units sold that month |
| Marketing_Spend | integer | Marketing spend, US dollars |

Two `Expenses` values (2022-03 and 2024-07) are deliberately missing
so the lab's `clean_sales_data()` function has real rows to drop, and
Q4 runs strongest so `summarize_by_quarter()` finds a clear top
quarter. Column names arrive in mixed case on purpose; lowercasing
them is part of the cleaning function.

**Load from the data pack root:**

```python
df_sales_monthly = pd.read_csv(
    'assets/code/chapter-10/monthly_sales.csv'
)
```

**Source:** Synthetic, generated with a fixed seed for this textbook.

## copperwind_weekly_metrics.csv

Sixty weeks of Copperwind operations metrics, used in Try It Yourself
10.5 as the input for a reusable reporting function. Engineered and
verified by the generator: exactly 3 missing values in
avg_resolution_hours and 2 in satisfaction_avg, so a cleaning step
has real work to do. 60 rows, 6 columns.

| Column | Type | Description |
|--------|------|-------------|
| week_start | date | Monday starting the week |
| tickets_opened | integer | Tickets opened that week |
| tickets_closed | integer | Tickets closed that week |
| avg_resolution_hours | float | Average hours to resolve, 3 missing |
| satisfaction_avg | float | Mean survey score, 2 missing |
| sla_met_pct | float | Percent of tickets meeting the SLA |

**Load from the data pack root:**

```python
df_weekly = pd.read_csv(
    'assets/code/chapter-10/copperwind_weekly_metrics.csv'
)
```

**Source:** Seeded synthetic data generated for this textbook (base
seed 215, byte-identical on rerun). Copperwind IT Services is a
fictional company created for this textbook. All names, clients, and
records are synthetic. Any resemblance to a real company or person is
coincidental.
